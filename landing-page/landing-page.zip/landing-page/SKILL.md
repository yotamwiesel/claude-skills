---
name: landing-page
description: Build Hebrew RTL landing pages from a proven template. This skill should be used when the user asks to "create a landing page", "build a new landing page", "make a landing page for [product]", or "replicate the workshop website". Produces a single-file HTML landing page with inline CSS/JS, deployed via Vercel then WordPress.
---

# Landing Page Builder

Build Hebrew RTL landing pages from a battle-tested template. The template lives at `assets/template.html` inside this skill's directory. Every new landing page starts by copying this template and replacing content slots.

## When to Use

- User asks to create a new landing page for a product/service/event
- User asks to replicate or clone the workshop website
- User asks to build a sales page or event page

## Workflow

### Step 1: Gather Required Content

Before touching code, collect from the user:

1. **Product/Service name** - what the page is selling
2. **Color scheme** - primary accent color and secondary accent (replaces orange #FF6D1F / #FF8F4F)
3. **Hero copy** - main headline, subtitle, body text
4. **Event details** - date, time, location (for pills)
5. **Hero video** - Vimeo embed ID
6. **Section copy** - content for each of the 17 sections (see Section Map below)
7. **Images** - instructor photos, gallery photos, testimonial screenshots
8. **Vimeo video testimonial IDs** - 4 testimonial video IDs + names
9. **Lottie animation URLs** - 5 for skill cards, 1 for bonus cards (user picks from lottiefiles.com)
10. **Marquee tool logos** - URLs for the scrolling tool strip
11. **WhatsApp number** - for footer link
12. **Google Sheets form endpoint** - Apps Script web app URL
13. **Countdown target date** - ISO format with timezone

### Step 2: Copy Template

```bash
cp [SKILL_DIR]/assets/template.html [PROJECT_DIR]/landing-page.html
```

Also create an index.html redirect:
```html
<!DOCTYPE html>
<html>
<head><meta http-equiv="refresh" content="0;url=landing-page.html"></head>
<body></body>
</html>
```

### Step 3: Replace Color Slots

Find and replace these CSS variable values in the `:root`/`.ws-wrapper` block:

| Variable | Default | Purpose |
|----------|---------|---------|
| `--purple` | `#FF6D1F` | Primary accent (buttons, borders, highlights) |
| `--yellow` | `#FF8F4F` | Secondary accent (prices, counter numbers, gradients) |
| `--purple-gradient` | `linear-gradient(90deg, #FF6D1F, #FF8F4F)` | Gradient accent |

Also update these hardcoded color references throughout the CSS:
- `rgba(224, 122, 58, ...)` - primary accent with alpha (dark section glow, cream stripes, input borders)
- `rgba(244, 162, 97, ...)` - secondary accent with alpha (dark section glow)
- `rgba(255, 109, 31, ...)` - primary in pulse animation
- Button hover background: change from purple to a darker shade of the new primary
- Header button background: `rgba(180, 90, 40, 0.9)` - adjust to match new scheme

### Step 4: Replace Content in Each Section

See Section Map below for exact content slots per section.

### Step 5: Replace Assets

- Copy and compress images with `sips -Z 1200 [image]` (macOS)
- Place in `images/` subdirectory
- Update all `src` attributes

### Step 6: Deploy

1. Preview: `python3 -m http.server 8850` then test locally
2. Vercel preview: `vercel --prod --yes` (account: peleg-jpg)
3. Final: WordPress deployment

---

## Section Map (17 Sections in Order)

Every section is wrapped in `.ws-wrapper`. All text is Hebrew RTL.

### 1. Header (`.ws-header`)
- **Logo text**: Brand name (Discovery font, yellow, uppercase)
- **CTA button text**: Short call-to-action linking to `#ws-register`

### 2. Hero (`.ws-hero.ws-section-dark`)
- **h1**: Main headline (68px Discovery desktop, 47px mobile)
  - Supports `<span style="color: var(--purple)">` for accent words
  - Supports `<br class="ws-mobile-break">` for mobile line breaks
- **Body text**: 1-2 paragraphs (18px, white, 0.85 opacity)
- **Vimeo iframe**: 16:9 aspect ratio, hero video
- **Subtitle**: Secondary headline (22px, white)
- **Pills**: 3 info pills (date, time, location) with SVG icons
- **CTA button**: Links to `#ws-register`

### 3. Marquee (`.ws-marquee-section`)
- **Title**: Section heading (e.g., "Tools we'll learn")
- **Logo images**: 10 tool logos, duplicated for infinite scroll
  - Each: 200px wide, 120px tall, contain fit
  - Animation: `ws-marquee 25s linear infinite`

### 4. Info Section (`.ws-whatiscc.ws-section-cream`)
- **Zigzag dividers**: Top and bottom (SVG, cream fill)
- **Title**: Section heading
- **Zigzag line**: Decorative SVG under title
- **Body text**: Description paragraph
- **Checklist**: 5 items with green checkmark SVG icons
- **CTA button**: Links to `#ws-register`
- **Image**: Right column image (hidden on mobile <1024px)

### 5. Early Registration Form (`.ws-registration.ws-section-dark`)
- **Heading**: Form title with `<br>` for line break
- **Form fields**: name (text), phone (tel), email (email) - all required
- **Submit button**: Discovery font, uppercase

### 6. Video Testimonials (`.ws-video-rec.ws-section-white`)
- **Title**: Section heading (52px)
- **Subtitle**: Description text
- **Video grid**: Horizontal scroll with snap, 4 cards
  - Each card: Vimeo iframe (9:16 aspect), person name below
  - 320px max-width per card
- **Navigation arrows**: Left/right, shown only on mobile (<768px)
  - Right arrow: `&#8249;` (points right in RTL context)
  - Left arrow: `&#8250;` (points left in RTL context)
  - Hide at scroll edges

### 7. Skills Grid (`.ws-section-dark`, inline padding)
- **Title**: What you'll know after (52px)
- **5 skill cards** in a 5-column grid (3/2/1 responsive)
  - Each: Lottie animation (105px) + title text
  - `<dotlottie-wc src="[URL]" autoplay loop style="width:105px;height:105px;"></dotlottie-wc>`
  - Hover: border color change + lift

### 8. Instructors (`.ws-about.ws-section-dark`)
- **Title**: "Who teaches?" (52px)
- **2 instructor cards** side by side (stack on mobile)
  - Cutout image (300px max-width)
  - Name in POLIN font (32px)
  - Bio paragraphs with `<strong>` emphasis
- **CTA button**: Below cards

### 9. Curriculum Accordion (`.ws-curriculum.ws-section-dark`)
- **Title**: Curriculum heading (52px)
- **6 module cards** (max-width 900px centered)
  - Number circle (36px, orange bg)
  - Module title + time
  - Expandable body with checklist items
  - Toggle via `wsToggleModule(this)` onclick
  - First module open by default (`.ws-module-open`)

### 10. Photo Gallery (`.ws-testimonials.ws-section-cream`)
- **Zigzag dividers**: Top/bottom
- **Title**: Gallery heading
- **4-column grid** (2 cols on mobile)
  - 8 images, 4:3 aspect ratio
  - Hover: scale(1.08) + brightness(1.1)

### 11. Bonuses (`.ws-bonuses.ws-section-dark`)
- **Title**: Bonuses heading (52px)
- **3-column grid** (2/1 responsive)
  - 6 bonus cards with Lottie icon (75px) + title + description
  - All 6 use the SAME Lottie URL
  - Hover: border color change + lift

### 12. For Whom (`.ws-forwhom.ws-section-white`)
- **Title**: Suitability heading (52px)
- **2-column layout**:
  - Green column: "Perfect if..." - 5 checkmark items
  - Red column: "Not for you if..." - 4 X items
  - Stack on mobile, green first

### 13. WhatsApp Testimonials (`.ws-section-cream`, inline styles)
- **Title**: Testimonials heading
- **Single image**: Screenshot of WhatsApp group testimonials
  - Max-width 800px, centered, rounded corners, shadow

### 14. Pricing (`.ws-pricing.ws-section-dark`)
- **Title**: Pricing heading (52px)
- **Price box** (max-width 600px centered):
  - Old price (strikethrough, 22px)
  - New price (80px yellow Discovery)
  - VAT calculation note
  - What's included description
  - Payment method note
  - Context comparison text
  - CTA button

### 15. Countdown + Registration (`.ws-registration.ws-section-dark`, id="ws-register")
- **Countdown timer**: 4 units (days/hours/minutes/seconds)
  - `dir="ltr"` on container (days LEFT, seconds RIGHT)
  - Yellow numbers (48px), white labels
  - Orange border on each unit
- **Expired message**: Hidden by default, shown when countdown reaches 0
- **Registration form**: Same as early form (Step 5)

### 16. FAQ (`.ws-faq.ws-section-dark`)
- **Title**: FAQ heading (52px)
- **Accordion items** (max-width 800px centered):
  - Question (clickable header, 20px)
  - Answer (expandable body, max-height 300px)
  - Toggle via `wsToggleFaq(this)` onclick
  - Orange border, purple when open

### 17. Footer (`.ws-footer`)
- **Closing text**: Short farewell message (20px)
- **Name**: Sender name (35px yellow Discovery)
- **WhatsApp link**: Icon + text, opens WhatsApp chat

---

## Fixed Infrastructure (Do NOT Change)

These elements stay the same across all landing pages:

### Fonts
- **Discovery** (Light 300, Bold 700) - headlines, buttons, prices, counters
- **POLIN** (Light 300, Medium 500, Bold 700, Black 900) - instructor names
- **Noto Sans Hebrew** (400-800) - body text fallback
- Font sources: aiagentschool.co.il CDN + Google Fonts

### External Dependencies
```html
<script src="https://unpkg.com/@lottiefiles/dotlottie-wc@0.9.3/dist/dotlottie-wc.js" type="module"></script>
```

### Dark Section Pattern
Radial gradient glows + repeating 50px grid lines overlay. Always use on `.ws-section-dark`.

### Cream Section Pattern
Cream background + diagonal stripe overlay at 135deg. Always use on `.ws-section-cream`.

### Scroll Animations
- Add `.ws-animate` class to elements for entrance animation
- IntersectionObserver adds `.ws-visible` at 10% threshold
- Transition: opacity 0.4s + translateY(15px to 0)
- Stagger with `.ws-animate-delay-1` through `.ws-animate-delay-4`

### CTA Button Style
- Discovery font, uppercase, italic
- Primary accent background, white text
- 2px black border + 5px hard shadow
- Floating animation (ws-float, 3s infinite)
- Hover: darker shade + lift

### Form Submission (JavaScript)
- Both forms submit via `fetch` POST to Google Apps Script
- Body: `{name, phone, email}` as JSON
- Mode: `no-cors`
- Success: green button "submitted!" for 3s
- Error: red button "error, try again"
- Placeholder endpoint: `FORM_ACTION = '#'` (replace with real URL)

### Countdown Timer (JavaScript)
- Set `WORKSHOP_DATE` variable to ISO date string with timezone
- Updates every 1 second
- When expired: hide countdown, show expired message

### Responsive Breakpoints
- **1024px**: Flex columns, 2-col grids, hide info section image
- **767px**: Mobile layout, single columns, 34px titles, show video arrows
- **480px**: Small mobile, 28px titles, minimum spacing

### RTL Handling
- `dir="rtl"` on `<html>`, `direction: rtl` on `.ws-wrapper`
- Countdown: `dir="ltr"` override
- Marquee: `direction: ltr` override
- All text alignment: right by default

---

## Checklist Before Delivery

- [ ] All Hebrew copy replaced
- [ ] Colors updated (CSS vars + hardcoded rgba values)
- [ ] All images compressed and loading
- [ ] Vimeo embeds working (hero + 4 testimonials)
- [ ] Lottie animations loading (5 skills + 6 bonuses)
- [ ] Form submission endpoint connected
- [ ] Countdown date set correctly
- [ ] WhatsApp number updated in footer
- [ ] Mobile responsive (test at 390px, 768px, 1024px)
- [ ] Video arrows working on mobile (hide at edges)
- [ ] Accordion toggles working (curriculum + FAQ)
- [ ] Marquee scrolling with correct logos
- [ ] Served on localhost:8850 and visually verified
- [ ] Deployed to Vercel for preview
